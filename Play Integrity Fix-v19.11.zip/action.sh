#!/system/bin/sh
echo "
             Elawawni_root (Powered by @El_awawni)
╗────────────────────────────────────────╔
      au_z3@
      @El_awawni
      ───────────────────╚
"
sleep 2
echo " ✅ Automatic update by @El_awawni ✅"
ping -w 1 google.com &>/dev/null
if [ $? -ne 0 ]; then
    echo "   مرحبآ بك في سكربت @El_awawni 🚥 الرجاء التأكد من الاتصال بالإنترنت 🚧 "
    sleep 2
    exit 1
fi

# ✅ Downloading update files - powered by @El_awawni
curl -o /data/adb/tricky_store/keybox.xml https://raw.githubusercontent.com/Sul6666/msup/refs/heads/main/key.xml
curl -o /data/adb/pif.json https://raw.githubusercontent.com/Sul6666/msup/refs/heads/main/pif.json
curl -o /data/adb/tricky_store/target.txt https://raw.githubusercontent.com/Sul6666/msup/refs/heads/main/target.txt

echo
echo
echo
echo " 🚨 لمتابعة كل جديد من تطوير @Elawawni_Root انضم إلى قناتنا على تليجرام 💻"
sleep 4
echo "▬▬▬.◙.▬▬▬"
echo "═▂▄▄▓▄▄▂"
echo "◢◤ █▀▀████▄▄▄▄◢◤"
echo "█▄ █ █▄ ███▀▀▀▀▀▀▀╬"
echo "◥█████◤"
echo "══╩══╩═"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬☻/ تم التثبيت بنجاح!"
echo "╬═╬/▌ ✅ Powered by @El_awawni ✅"
echo "╬═╬/ \\"
echo " "
sleep 1

# ✅ توجيه المستخدم تلقائياً لقناة @Elawawni_Root
nohup am start -a android.intent.action.VIEW -d https://t.me/Elawawni_Root >/dev/null 2>&1 || xdg-open https://t.me/Elawawni_Root >/dev/null 2>&1

echo
echo
echo "            🔰 تم التحديث بنجاح بواسطة @El_awawni 🔰"
echo
echo  
sleep 1
