#!/system/bin/sh

# Play Integrity Fix - customize.sh
# تم التعديل بواسطة @El_awawni

# لا يتم الفلاش من الريكفري
if ! $BOOTMODE; then
  ui_print "****************************************"
  ui_print "! لا يمكن التثبيت من الريكفري!"
  ui_print "! استخدم Magisk أو KernelSU فقط"
  abort  "****************************************"
fi

# منع التثبيت على أندرويد أقل من 8
if [ "$API" -lt 26 ]; then
  abort "! لا يمكن استخدام هذه الإضافة على أندرويد أقل من 8.0"
fi

# التأكد من وجود Zygisk
check_zygisk() {
  local MAGISK_DIR="/data/adb/magisk"
  local ZYGISK_STATUS
  ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")
  [ "$ZYGISK_STATUS" = "value=0" ] && abort "! Zygisk غير مفعل. قم بتفعيله أولاً."
}
check_zygisk

# إزالة إضافات قد تسبب تعارض
for mod in safetynet-fix playcurl busybox-ndk; do
  [ -d "/data/adb/modules/$mod" ] && touch "/data/adb/modules/$mod/remove"
done

# تحذير بخصوص MagiskHidePropsConf
[ -d "/data/adb/modules/MagiskHidePropsConf" ] && ui_print "! تحذير: قد تسبب مشاكل مع هذه الإضافة"

# نسخ ملفات التهيئة
[ -f "/data/adb/pif.json" ] && mv -f /data/adb/pif.json /data/adb/pif.json.old
cp -f "$MODPATH/security_patch.txt" /data/adb/tricky_store/ 2>/dev/null

# إعداد ملفات spoof
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" >/dev/null 2>&1

keybox=$(find "$MODPATH/zygisk" -type f -name "*.@s" | shuf -n 1)
[ -z "$keybox" ] && abort "! لم يتم العثور على ملفات keybox"
cp "$keybox" "/data/adb/tricky_store/keybox.xml"

target=$(find "$MODPATH/zygisk" -type f -name "*.x" | shuf -n 1)
[ -z "$target" ] && abort "! لم يتم العثور على ملفات bootloader spoof"
cp "$target" "/data/adb/tricky_store/target.txt"

# ضبط صلاحيات الملفات
chmod +x "$MODPATH/action.sh"

# ✅ تحويل المستخدم إلى قناة @Elawawni_Root بعد التثبيت
nohup am start -a android.intent.action.VIEW -d "https://t.me/Elawawni_Root" >/dev/null 2>&1 &

# ✅ إضافة التطبيقات المهمة إلى denylist (يمكنك تعديلها لاحقًا حسب الحاجة)
su -c "magisk --denylist add com.google.android.gms"
su -c "magisk --denylist add com.android.vending"

# تم ✔️
ui_print "- تم التثبيت بنجاح بواسطة @El_awawni"
